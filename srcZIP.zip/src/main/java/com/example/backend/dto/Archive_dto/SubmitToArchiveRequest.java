package com.example.backend.dto.Archive_dto;

public record SubmitToArchiveRequest(
        Integer checklistId
) {
}
